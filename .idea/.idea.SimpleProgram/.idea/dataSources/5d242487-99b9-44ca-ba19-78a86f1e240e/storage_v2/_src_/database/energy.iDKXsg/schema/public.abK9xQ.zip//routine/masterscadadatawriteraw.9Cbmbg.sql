create function masterscadadatawriteraw(a_projectid integer, a_layer integer, a_itemid integer, a_time bigint, a_value double precision, a_quality integer, a_flags integer)
  returns void
language plpgsql
as $$
BEGIN
    INSERT INTO MasterSCADADataRaw VALUES (a_ProjectID, a_Layer, a_ItemID, a_Time, a_Value, null, a_Quality, a_Flags);
END
$$;

alter function masterscadadatawriteraw(integer, integer, integer, bigint, double precision, integer, integer)
  owner to postgres;

