create function masterscadadatawriterawstring(a_projectid integer, a_layer integer, a_itemid integer, a_time bigint, a_value text, a_quality integer, a_flags integer)
  returns void
language plpgsql
as $$
BEGIN
    INSERT INTO MasterSCADADataRaw VALUES (a_ProjectID, a_Layer, a_ItemID, a_Time, null, a_Value, a_Quality, a_Flags);
END
$$;

alter function masterscadadatawriterawstring(integer, integer, integer, bigint, text, integer, integer)
  owner to postgres;

