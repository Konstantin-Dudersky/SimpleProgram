create function masterscadadatareadraw(a_projectid integer, a_layer integer, a_itemid integer, a_starttime bigint, a_endtime bigint, a_maxvalues integer)
  returns TABLE(a_time bigint, a_value double precision, a_stringvalue text, a_quality integer, a_flags integer)
language plpgsql
as $$
BEGIN
	IF (a_MaxValues is null) THEN
		RETURN QUERY
		SELECT "Time", Value, StringValue, Quality, Flags FROM MasterSCADADataRaw WHERE
			ProjectID = a_ProjectID and
			Layer     = a_Layer     and
			ItemID    = a_ItemID    and
			"Time"   <= a_EndTime   and
			"Time"   >= a_StartTime
			ORDER BY ProjectID, Layer, ItemID, "Time";
	ELSE
		RETURN QUERY
		SELECT "Time", Value, StringValue, Quality, Flags FROM MasterSCADADataRaw WHERE 
			ProjectID = a_ProjectID and
			Layer     = a_Layer     and
			ItemID    = a_ItemID    and 
			"Time"   <= a_EndTime   and
			"Time"   >= a_StartTime
			ORDER BY ProjectID, Layer, ItemID, "Time"
			LIMIT a_MaxValues;
	END IF;
END
$$;

alter function masterscadadatareadraw(integer, integer, integer, bigint, bigint, integer)
  owner to postgres;

