create function masterscadadatareaditemfirstlasttimes(a_projectid integer, a_itemid integer, OUT a_firsttime bigint, OUT a_lasttime bigint)
  returns record
language plpgsql
as $$
BEGIN
    SELECT FirstTime, LastTime FROM MasterSCADADataItems WHERE
	ProjectID = a_ProjectID and
	ItemID    = a_ItemID
	INTO a_FirstTime, a_LastTime;
END
$$;

alter function masterscadadatareaditemfirstlasttimes(integer, integer, out bigint, out bigint)
  owner to postgres;

