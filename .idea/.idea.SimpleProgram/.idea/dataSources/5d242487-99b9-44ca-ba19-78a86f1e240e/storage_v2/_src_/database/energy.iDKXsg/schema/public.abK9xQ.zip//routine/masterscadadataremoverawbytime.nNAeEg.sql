create function masterscadadataremoverawbytime(a_projectid integer, a_layer integer, a_itemid integer, a_mintime bigint DEFAULT NULL::bigint, a_valuescount integer DEFAULT 10000, OUT a_removedcount integer)
  returns integer
language plpgsql
as $$
BEGIN
	IF (a_MinTime is null) THEN
		BEGIN
			IF (a_Layer is null) and (a_ItemID is null) THEN
				SELECT MAX(T."Time") FROM (SELECT "Time" FROM MasterSCADADataRaw WHERE
					ProjectID = a_ProjectID
					ORDER BY ProjectID, Layer, ItemID, "Time"
					LIMIT a_ValuesCount) T
				INTO a_MinTime;
			ELSIF (a_ItemID is null) THEN
				SELECT MAX(T."Time") FROM (SELECT "Time" FROM MasterSCADADataRaw WHERE
					ProjectID = a_ProjectID and
					Layer     = a_Layer
					ORDER BY ProjectID, Layer, ItemID, "Time"
					LIMIT a_ValuesCount) T
				INTO a_MinTime;
			ELSIF (a_Layer is null) THEN
				SELECT MAX(T."Time") FROM (SELECT "Time" FROM MasterSCADADataRaw WHERE
					ProjectID = a_ProjectID and
					ItemID    = a_ItemID
					ORDER BY ProjectID, Layer, ItemID, "Time"
					LIMIT a_ValuesCount) T
				INTO a_MinTime;
			ELSE
				SELECT MAX(T."Time") FROM (SELECT "Time" FROM MasterSCADADataRaw WHERE
					ProjectID = a_ProjectID and
					Layer     = a_Layer and
					ItemID    = a_ItemID
					ORDER BY ProjectID, Layer, ItemID, "Time"
					LIMIT a_ValuesCount) T
				INTO a_MinTime;
			END IF;
			IF (a_MinTime is null) THEN
				a_RemovedCount := 0;
				RETURN;
			END IF;
		END;
	END IF;
	IF (a_Layer is null) and (a_ItemID is null) THEN
		DELETE FROM MasterSCADADataRaw WHERE 
			ProjectID = a_ProjectID and
			"Time"    < a_MinTime;
	ELSIF (a_ItemID is null) THEN
		DELETE FROM MasterSCADADataRaw WHERE 
			ProjectID = a_ProjectID and
			Layer     = a_Layer and
			"Time"    < a_MinTime;
	ELSIF (a_Layer is null) THEN
		DELETE FROM MasterSCADADataRaw WHERE 
			ProjectID = a_ProjectID and
			ItemID    = a_ItemID and
			"Time"    < a_MinTime;
	ELSE
		DELETE FROM MasterSCADADataRaw WHERE 
			ProjectID = a_ProjectID and
			Layer     = a_Layer and
			ItemID    = a_ItemID and
			"Time"   <= a_MinTime;
	END IF;
	GET DIAGNOSTICS a_RemovedCount = ROW_COUNT;
END
$$;

alter function masterscadadataremoverawbytime(integer, integer, integer, bigint, integer, out integer)
  owner to postgres;

