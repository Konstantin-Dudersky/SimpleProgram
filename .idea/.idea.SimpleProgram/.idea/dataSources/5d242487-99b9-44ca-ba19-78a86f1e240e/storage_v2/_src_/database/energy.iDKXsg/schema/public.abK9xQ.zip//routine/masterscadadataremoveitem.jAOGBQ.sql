create function masterscadadataremoveitem(a_projectid integer, a_itemid integer)
  returns void
language plpgsql
as $$
BEGIN
	DELETE FROM MasterSCADADataItems WHERE ProjectID = a_ProjectID and ItemID = a_ItemID;
END;
$$;

alter function masterscadadataremoveitem(integer, integer)
  owner to postgres;

